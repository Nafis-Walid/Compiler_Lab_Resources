#include<math.h> 
int main()
{ 
    float a, b, c;  
    a=1;  
    b=2;  
    c=a+b; 
    return 0; 
}
